import React from 'react'

import { useState } from 'react';

export default function RecipeDrawer({ recipe, onClose }){
  if(!recipe) return null
  const n = recipe.nutrients || {}
  const [showTimes, setShowTimes] = React.useState(false)

  return (
    <div style={{
      position:'fixed', top:0, right:0, width:'420px', height:'100%',
      background:'#fff', borderLeft:'1px solid #ddd', boxShadow:'-4px 0 20px rgba(0,0,0,0.05)',
      padding:16, overflowY:'auto'
    }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <h2 style={{ margin:0 }}>{recipe.title}</h2>
        <button onClick={onClose}>Close</button>
      </div>
      <div style={{ color:'#666', marginBottom:12 }}>{recipe.cuisine}</div>

      <div style={{ marginBottom:12 }}>
        <strong>Description:</strong>
        <div>{recipe.description || '-'}</div>
      </div>

      <div style={{ marginBottom:12 }}>
        <strong>Total Time:</strong> {recipe.total_time ?? '-'}
        <button style={{ marginLeft:8 }} onClick={()=>setShowTimes(s=>!s)}>{showTimes? 'Hide' : 'Expand'}</button>
        {showTimes && (
          <div style={{ marginTop:6, paddingLeft:8 }}>
            <div>Cook Time: {recipe.cook_time ?? '-'}</div>
            <div>Prep Time: {recipe.prep_time ?? '-'}</div>
          </div>
        )}
      </div>

      <div>
        <strong>Nutrition</strong>
        <table style={{ width:'100%', borderCollapse:'collapse', marginTop:8 }}>
          <tbody>
            {['calories','carbohydrateContent','cholesterolContent','fiberContent','proteinContent','saturatedFatContent','sodiumContent','sugarContent','fatContent']
              .map(k => (
                <tr key={k}>
                  <td style={{ padding:6, borderBottom:'1px solid #f1f1f1' }}>{k}</td>
                  <td style={{ padding:6, borderBottom:'1px solid #f1f1f1' }}>{n[k] ?? '-'}</td>
                </tr>
              ))
            }
          </tbody>
        </table>
      </div>
    </div>
  )
}
