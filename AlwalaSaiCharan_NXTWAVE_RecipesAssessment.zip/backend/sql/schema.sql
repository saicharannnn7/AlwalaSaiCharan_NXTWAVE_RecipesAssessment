-- PostgreSQL schema
CREATE TABLE IF NOT EXISTS recipes (
    id SERIAL PRIMARY KEY,
    cuisine VARCHAR(100),
    title VARCHAR(255) NOT NULL,
    rating FLOAT NULL,
    prep_time INT NULL,
    cook_time INT NULL,
    total_time INT NULL,
    description TEXT,
    nutrients JSONB,
    serves VARCHAR(50)
);

-- Helpful indexes
CREATE INDEX IF NOT EXISTS idx_recipes_rating ON recipes (rating DESC NULLS LAST);
CREATE INDEX IF NOT EXISTS idx_recipes_cuisine ON recipes (cuisine);
CREATE INDEX IF NOT EXISTS idx_recipes_title ON recipes (title);
CREATE INDEX IF NOT EXISTS idx_recipes_nutrients_gin ON recipes USING GIN (nutrients);
