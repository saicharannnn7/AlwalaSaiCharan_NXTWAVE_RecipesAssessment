import os
import re
from fastapi import FastAPI, Depends, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import text, select, func, desc, or_, and_
from typing import Optional

from .db import get_db
from .models import Recipe
from .schemas import RecipeOut, PaginatedResponse

app = FastAPI(title="Recipes API")

# CORS for local dev (React at 5173)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def parse_numeric_op(value: Optional[str]):
    """Parse strings like '>=4.5', '<=120', '=3.0', '400'.
    Returns (operator, number) or (None, None) if invalid.
    """
    if value is None:
        return None, None
    m = re.match(r"^(<=|>=|=|<|>)?\s*([0-9]+(?:\.[0-9]+)?)$", value.strip())
    if not m:
        return None, None
    op = m.group(1) or '='
    num = float(m.group(2))
    return op, num

@app.get('/health')
def health():
    return {"status": "ok"}

@app.get('/api/recipes', response_model=PaginatedResponse)
def get_recipes(
    page: int = Query(1, ge=1),
    limit: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db)
):
    q = db.query(Recipe)
    # sort by rating desc nulls last
    q = q.order_by(desc(Recipe.rating).nullslast())
    total = q.count()
    items = q.offset((page-1)*limit).limit(limit).all()
    data = [RecipeOut.model_validate(i) for i in items]
    return {"page": page, "limit": limit, "total": total, "data": data}

@app.get('/api/recipes/search')
def search_recipes(
    title: Optional[str] = None,
    cuisine: Optional[str] = None,
    total_time: Optional[str] = None,  # with operator e.g. '<=120'
    rating: Optional[str] = None,      # with operator e.g. '>=4.5'
    calories: Optional[str] = None,    # with operator e.g. '<=400'
    page: int = Query(1, ge=1),
    limit: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db)
):
    q = db.query(Recipe)
    filters = []

    if title:
        filters.append(Recipe.title.ilike(f"%{title}%"))

    if cuisine:
        # exact or partial (use ilike for convenience)
        filters.append(Recipe.cuisine.ilike(f"%{cuisine}%"))

    # rating filter
    rop, rnum = parse_numeric_op(rating)
    if rop and rnum is not None:
        if rop == '=':
            filters.append(Recipe.rating == rnum)
        elif rop == '>':
            filters.append(Recipe.rating > rnum)
        elif rop == '>=':
            filters.append(Recipe.rating >= rnum)
        elif rop == '<':
            filters.append(Recipe.rating < rnum)
        elif rop == '<=':
            filters.append(Recipe.rating <= rnum)

    # total_time filter
    top, tnum = parse_numeric_op(total_time)
    if top and tnum is not None:
        if top == '=':
            filters.append(Recipe.total_time == int(tnum))
        elif top == '>':
            filters.append(Recipe.total_time > int(tnum))
        elif top == '>=':
            filters.append(Recipe.total_time >= int(tnum))
        elif top == '<':
            filters.append(Recipe.total_time < int(tnum))
        elif top == '<=':
            filters.append(Recipe.total_time <= int(tnum))

    # calories filter - extract numeric from JSONB nutrients->>'calories'
    cop, cnum = parse_numeric_op(calories)
    if cop and cnum is not None:
        # Build a text() predicate: regexp_replace((nutrients->>'calories'), '[^0-9.]','','g')::float [op] cnum
        cal_expr = text("(regexp_replace(nutrients->>'calories', '[^0-9.]', '', 'g'))::float")
        if cop == '=':
            filters.append(cal_expr == cnum)
        elif cop == '>':
            filters.append(cal_expr > cnum)
        elif cop == '>=':
            filters.append(cal_expr >= cnum)
        elif cop == '<':
            filters.append(cal_expr < cnum)
        elif cop == '<=':
            filters.append(cal_expr <= cnum)

    if filters:
        q = q.filter(and_(*filters))

    # Default sort by rating desc
    q = q.order_by(desc(Recipe.rating).nullslast())

    total = q.count()
    items = q.offset((page-1)*limit).limit(limit).all()
    data = [RecipeOut.model_validate(i) for i in items]
    return {"page": page, "limit": limit, "total": total, "data": data}
