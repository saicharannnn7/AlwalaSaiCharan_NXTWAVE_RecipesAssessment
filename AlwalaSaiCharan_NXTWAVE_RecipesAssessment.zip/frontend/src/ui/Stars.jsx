import React from 'react'

export default function Stars({ value }){
  if(value == null) return <span>-</span>
  const full = Math.floor(value)
  const half = value - full >= 0.5 ? 1 : 0
  const empty = 5 - full - half
  return (
    <span aria-label={`Rating ${value}`}>
      {'★'.repeat(full)}
      {half ? '☆' : ''}
      {'☆'.repeat(empty)}
      <span style={{ marginLeft: 6, fontSize:12, color:'#555' }}>{value.toFixed(1)}</span>
    </span>
  )
}
