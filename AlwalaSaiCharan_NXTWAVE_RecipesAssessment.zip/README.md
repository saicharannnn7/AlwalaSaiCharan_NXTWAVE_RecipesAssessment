# Recipe Data Collection and API Development

This is a complete example project fulfilling the assignment:

- Parse JSON recipes
- Store in PostgreSQL
- REST API with pagination, sorting, and search
- React UI with table, drawer, filters, and pagination

## Quick Start

### 1) Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt

# Create DB and schema
psql -U postgres -c "CREATE DATABASE recipes_db;"
psql -d recipes_db -f sql/schema.sql

# Configure env
cp .env.example .env

# Load sample data
python load_data.py ../data/sample.json

# Run API
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 2) Frontend
```bash
cd ../frontend
npm install
npm run dev
# visit http://localhost:5173
```

### API Examples
- `GET http://localhost:8000/api/recipes?page=1&limit=10`
- `GET http://localhost:8000/api/recipes/search?title=pie&rating=>=4.5&calories=<=400&total_time=<=120&page=1&limit=15`
