import React from 'react'
import Stars from './Stars'

function truncate(text, max=40){
  if(!text) return ''
  return text.length>max ? text.slice(0,max-1)+'…' : text
}

export default function RecipesTable({ rows, onSelect }){
  if (!recipes || recipes.length === 0) {
    return (
      <div className="text-center text-gray-500 mt-10">
        No recipes found. Try adjusting your filters!
      </div>
    );
  }

  return (
    <div style={{ overflowX:'auto' }}>
      <table style={{ width:'100%', borderCollapse:'collapse' }}>
        <thead>
          <tr>
            <th style={{ textAlign:'left', borderBottom:'1px solid #ddd', padding:8 }}>Title</th>
            <th style={{ textAlign:'left', borderBottom:'1px solid #ddd', padding:8 }}>Cuisine</th>
            <th style={{ textAlign:'left', borderBottom:'1px solid #ddd', padding:8 }}>Rating</th>
            <th style={{ textAlign:'left', borderBottom:'1px solid #ddd', padding:8 }}>Total Time</th>
            <th style={{ textAlign:'left', borderBottom:'1px solid #ddd', padding:8 }}>Serves</th>
          </tr>
        </thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.id} onClick={()=>onSelect(r)} style={{ cursor:'pointer' }}>
              <td style={{ padding:8, borderBottom:'1px solid #f1f1f1' }}>{truncate(r.title, 50)}</td>
              <td style={{ padding:8, borderBottom:'1px solid #f1f1f1' }}>{r.cuisine || '-'}</td>
              <td style={{ padding:8, borderBottom:'1px solid #f1f1f1' }}><Stars value={r.rating} /></td>
              <td style={{ padding:8, borderBottom:'1px solid #f1f1f1' }}>{r.total_time ?? '-'}</td>
              <td style={{ padding:8, borderBottom:'1px solid #f1f1f1' }}>{r.serves || '-'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
