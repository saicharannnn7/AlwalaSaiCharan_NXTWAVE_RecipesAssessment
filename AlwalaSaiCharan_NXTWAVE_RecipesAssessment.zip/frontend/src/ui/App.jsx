import React, { useEffect, useMemo, useState } from 'react'
import RecipesTable from './RecipesTable'
import RecipeDrawer from './RecipeDrawer'

export default function App() {
  const [recipes, setRecipes] = useState([])
  const [page, setPage] = useState(1)
  const [limit, setLimit] = useState(15)
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(false)
  const [selected, setSelected] = useState(null)
  const [filters, setFilters] = useState({ title: '', cuisine: '', rating: '', total_time: '', calories: '' })
  const [searchMode, setSearchMode] = useState(false)

  const fetchData = async () => {
    setLoading(true)
    try {
      const base = searchMode ? '/api/recipes/search' : '/api/recipes'
      const params = new URLSearchParams()
      params.set('page', page)
      params.set('limit', limit)
      if (searchMode) {
        Object.entries(filters).forEach(([k,v]) => { if (v) params.set(k, v) })
      }
      const res = await fetch(`${base}?${params.toString()}`)
      const json = await res.json()
      setRecipes(json.data || json)
      setTotal(json.total || 0)
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchData() }, [page, limit, searchMode])

  const onSearch = () => {
    setPage(1)
    setSearchMode(true)
    fetchData()
  }

  const onClear = () => {
    setFilters({ title: '', cuisine: '', rating: '', total_time: '', calories: '' })
    setSearchMode(false)
    setPage(1)
    fetchData()
  }

  return (
    <div style={{ fontFamily: 'system-ui, Arial', padding: 16 }}>
      <h1>Recipes</h1>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(5, 1fr) auto auto', gap:8, alignItems:'end', marginBottom:12 }}>
        <div>
          <label>Title</label>
          <input value={filters.title} onChange={e=>setFilters({...filters, title:e.target.value})} placeholder="e.g. pie" style={{width:'100%'}}/>
        </div>
        <div>
          <label>Cuisine</label>
          <input value={filters.cuisine} onChange={e=>setFilters({...filters, cuisine:e.target.value})} placeholder="e.g. Southern" style={{width:'100%'}}/>
        </div>
        <div>
          <label>Rating</label>
          <input value={filters.rating} onChange={e=>setFilters({...filters, rating:e.target.value})} placeholder="e.g. >=4.5" style={{width:'100%'}}/>
        </div>
        <div>
          <label>Total Time</label>
          <input value={filters.total_time} onChange={e=>setFilters({...filters, total_time:e.target.value})} placeholder="e.g. <=120" style={{width:'100%'}}/>
        </div>
        <div>
          <label>Calories</label>
          <input value={filters.calories} onChange={e=>setFilters({...filters, calories:e.target.value})} placeholder="e.g. <=400" style={{width:'100%'}}/>
        </div>
        <button onClick={onSearch}>Search</button>
        <button onClick={onClear}>Clear</button>
      </div>

      <div style={{ display:'flex', gap:12, alignItems:'center', marginBottom:8 }}>
        <label>Per page:</label>
        <select value={limit} onChange={e=>setLimit(Number(e.target.value))}>
          {[15,20,25,30,40,50].map(n=>(<option key={n} value={n}>{n}</option>))}
        </select>
        <span>Page {page} / {Math.max(1, Math.ceil(total/limit))}</span>
        <button disabled={page<=1} onClick={()=>setPage(p=>p-1)}>Prev</button>
        <button disabled={page>=Math.ceil(total/limit)} onClick={()=>setPage(p=>p+1)}>Next</button>
      </div>

      {(!recipes || recipes.length===0) && !loading ? (
        <div style={{ padding:24, border:'1px dashed #aaa', borderRadius:8}}>
          No results found. Try changing filters.
        </div>
      ) : null}

      <RecipesTable rows={recipes} onSelect={setSelected} />
      <RecipeDrawer recipe={selected} onClose={()=>setSelected(null)} />
    </div>
  )
}
