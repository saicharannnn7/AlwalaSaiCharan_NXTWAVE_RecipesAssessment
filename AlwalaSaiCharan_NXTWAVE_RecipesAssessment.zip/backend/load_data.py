import sys, os, json, math
from dotenv import load_dotenv
from sqlalchemy import insert
from sqlalchemy.orm import Session

from app.db import engine
from app.models import Recipe, Base

load_dotenv()

def is_nan_like(x):
    if x is None:
        return True
    if isinstance(x, float) and math.isnan(x):
        return True
    if isinstance(x, str) and x.strip().lower() == 'nan':
        return True
    return False

def to_int_or_none(x):
    try:
        if is_nan_like(x):
            return None
        return int(float(x))
    except Exception:
        return None

def to_float_or_none(x):
    try:
        if is_nan_like(x):
            return None
        return float(x)
    except Exception:
        return None

def main():
    if len(sys.argv) < 2:
        print("Usage: python load_data.py <path_to_json>")
        sys.exit(1)
    path = sys.argv[1]
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    # Ensure table exists
    Base.metadata.create_all(bind=engine)

    # Accept either list of recipes or single recipe
    if isinstance(data, dict):
        records = [data]
    else:
        records = data

    to_insert = []
    for rec in records:
        to_insert.append({
            'cuisine': rec.get('cuisine'),
            'title': rec.get('title'),
            'rating': to_float_or_none(rec.get('rating')),
            'prep_time': to_int_or_none(rec.get('prep_time')),
            'cook_time': to_int_or_none(rec.get('cook_time')),
            'total_time': to_int_or_none(rec.get('total_time')),
            'description': rec.get('description'),
            'nutrients': rec.get('nutrients') or None,
            'serves': rec.get('serves'),
        })

    with Session(engine) as session:
        session.bulk_insert_mappings(Recipe, to_insert)
        session.commit()

    print(f"Inserted {len(to_insert)} recipes.")

if __name__ == '__main__':
    main()
