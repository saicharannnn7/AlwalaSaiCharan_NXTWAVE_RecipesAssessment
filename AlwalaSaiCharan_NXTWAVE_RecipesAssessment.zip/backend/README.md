# Backend (FastAPI)

## Setup
1. Create and start PostgreSQL.
2. Create a database:
   ```sql
   CREATE DATABASE recipes_db;
   ```
3. Run schema:
   ```bash
   psql -d recipes_db -f sql/schema.sql
   ```
4. Copy `.env.example` to `.env` and update `DATABASE_URL` if needed.
5. (Optional) Load sample data:
   ```bash
   python load_data.py data/sample.json
   ```
6. Start server:
   ```bash
   uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
   ```

## Endpoints
- `GET /api/recipes?page=1&limit=10` — Paginated, sorted by `rating` DESC.
- `GET /api/recipes/search?title=pie&cuisine=Southern%20Recipes&rating=>=4.5&calories=<=400&total_time=<=120&page=1&limit=15`

### Operator Format
For numeric filters (`rating`, `total_time`, `calories`) use one of: `=, >, >=, <, <=` as a prefix, e.g. `>=4.2`.

- `calories` are parsed from `nutrients->>'calories'` (e.g. "389 kcal") using regex, non-digits ignored.
